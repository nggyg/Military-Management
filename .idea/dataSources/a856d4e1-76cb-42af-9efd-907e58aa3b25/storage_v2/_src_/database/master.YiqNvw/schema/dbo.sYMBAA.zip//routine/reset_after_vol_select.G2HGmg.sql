
create   procedure reset_after_vol_select
as
begin
	delete from volunteers
	update Applicants
	set volunteering=0
	where volunteering=1
end
go

