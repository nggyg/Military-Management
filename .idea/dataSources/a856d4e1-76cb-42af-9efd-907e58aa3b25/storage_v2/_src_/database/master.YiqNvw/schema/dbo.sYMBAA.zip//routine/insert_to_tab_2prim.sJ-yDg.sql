
create   procedure insert_to_tab_2prim(@nrmat int, @vname varchar(50),@age int)
as
begin
	insert into Applicants(NrMat,VName,age)
	values(@nrmat,@vname,@age)
end
go

