create   procedure create_default 
as
begin
	drop table Tc
	drop table Ta
	drop table Tb
	create table Ta(id_a int not null,a2 int unique,constraint PK_Ta primary key (id_a))
	create table Tb(id_b int not null,b2 int,constraint PK_Tb primary key (id_b))
	create table Tc(id_c int not null,id_a int,id_b int, c1 int, constraint PK_Tc primary key (id_c),foreign key (id_a) references Ta(id_a),foreign key (id_b) references Tb(id_b))
end
go

