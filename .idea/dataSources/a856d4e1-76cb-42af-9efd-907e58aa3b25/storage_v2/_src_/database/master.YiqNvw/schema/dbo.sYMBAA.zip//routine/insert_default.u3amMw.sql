
create   procedure insert_default 
as
begin
	declare @i int,@aux int
	set @i=0
	while @i<10000
	begin
		set @aux=@i+1
		insert into Ta(id_a,a2)
		values(@i,@aux)
		if @i<3000
		begin
			insert into Tb(id_b,b2)
			values(@i,@aux)
		end
		declare @id_b int
		declare Tb_sel cursor scroll for
					select top(3) id_b
					from Tb
					order by id_b desc
		open Tb_sel
			fetch first from Tb_sel
			into @id_b
			while @@FETCH_STATUS=0
			begin
				insert into Tc(id_c,id_a,id_b,c1)
				values(3*@i+@id_b,@i,@id_b,@aux)
				fetch next from Tb_sel
				into @id_b
			end
		close Tb_sel
		deallocate Tb_sel
		set @i=@i+1
	end
	insert into Tc(id_c,id_a,id_b,c1)
	values(40000,0,1,2),(40001,0,2,1),(40002,1,2,8)
end
go

