
create   procedure fake_fill
as
begin
	declare @i int =0, @a int, @b varchar(50), @c int;
	while @i < 10
	begin
		set @a=@i;
		set @b=cast('Alex'+cast(@i as varchar(50)) as varchar(50));
		set @c=14+ @i%8;
		exec insert_to_tab_2prim @a,@b,@c
		set @i=@i+1;
	end
end
go

