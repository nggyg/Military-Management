create   function test_ret_tab(@age int)
returns table as
return
	select * from Applicants
	where age=@age
go

