
create   procedure RB_create_table(@tab_name varchar(50))
as
	declare @SQLString nvarchar(MAX)
	set @SQLString='drop table '+@tab_name
	print (@SQLString)
	exec (@SQLString)
go

