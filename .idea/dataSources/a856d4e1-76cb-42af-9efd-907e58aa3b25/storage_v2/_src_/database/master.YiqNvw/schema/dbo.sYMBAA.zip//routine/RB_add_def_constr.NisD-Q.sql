
create   procedure RB_add_def_constr(@tab_name varchar(50),@col_name varchar(50))
as
	declare @command nvarchar(max)
	set @command='alter table '+@tab_name+
				' alter column '+@col_name+
				' drop default'
	print(@command)
	exec(@command)
go

