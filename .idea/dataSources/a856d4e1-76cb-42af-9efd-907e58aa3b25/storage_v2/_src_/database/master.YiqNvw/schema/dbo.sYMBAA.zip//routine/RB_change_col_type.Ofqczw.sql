
create   procedure RB_change_col_type(@tab_name varchar(50),@col_name varchar(50),@prev_col_type varchar(50))
as
	declare @command nvarchar(max)
	set @command='alter table '+@tab_name+' alter column '+@col_name+' '+@prev_col_type
	print(@command)
	exec(@command)
go

