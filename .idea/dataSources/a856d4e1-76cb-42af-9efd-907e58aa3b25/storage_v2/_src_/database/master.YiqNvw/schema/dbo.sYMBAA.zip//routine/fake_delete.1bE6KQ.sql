
create   procedure fake_delete
as
begin
	delete from Applicants
	where NrMat like '_'
end
go

