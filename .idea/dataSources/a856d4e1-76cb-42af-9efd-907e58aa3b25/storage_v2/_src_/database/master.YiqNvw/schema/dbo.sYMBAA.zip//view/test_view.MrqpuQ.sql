
create   view test_view as
select * from dbo.Volunteers
go

