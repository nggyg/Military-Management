create procedure test1(@input varchar(50))
as
	Select * from Studenten
	where Name=@input
go

