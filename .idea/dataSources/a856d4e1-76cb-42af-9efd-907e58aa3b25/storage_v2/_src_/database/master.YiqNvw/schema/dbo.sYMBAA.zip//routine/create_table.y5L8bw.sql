


create   procedure create_table(@tab_name varchar(50),@check int)
as
	declare @SQLString nvarchar(MAX)
	set @SQLString='create table '+@tab_name+' (id int primary key (id))'
	print (@SQLString)
	exec (@SQLString)
	if(@check=1)
		declare @ver int
		exec @ver=get_curr_ver
		insert into Proc_history (id,proc_name,col1)
		values (@ver,'create_table',@tab_name)
		update versions set id=id+1	
go

