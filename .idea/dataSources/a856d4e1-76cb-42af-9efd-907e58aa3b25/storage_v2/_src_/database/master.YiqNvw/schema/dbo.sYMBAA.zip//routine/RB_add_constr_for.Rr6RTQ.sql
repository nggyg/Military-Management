
create   procedure RB_add_constr_for(@tab_name varchar(50), @con_name varchar(100))
as
	declare @command nvarchar(max)
	set @command='alter table '+@tab_name+' drop constraint '+@con_name+';'
	print(@command)
	exec(@command)
go

