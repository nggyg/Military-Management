
create   procedure change_col_type(@tab varchar(50),@col varchar(50),@typ varchar(50))
as
begin
	declare @command nvarchar(max)
	set @command='alter table '+@tab+' alter column '+@col+' '+@typ
	print(@command)
	exec @command
end
go

