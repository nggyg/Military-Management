
create   procedure get_version(@version int)
as
go

