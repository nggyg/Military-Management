
create   procedure add_def_constr(@tab_name varchar(50),@col_name varchar(50),@def_var varchar(50),@check int)
as
	if(@check=1)
		declare @ver int
		exec @ver=get_curr_ver
		insert into Proc_history(id,proc_name,col1,col2)/*proc name, tab nam, col name*/
		values(@ver,'add_def_constr',@tab_name,@col_name)
		update versions set id=id+1
	declare @command nvarchar(max)
	set @command='alter table '+@tab_name+' add constraint df_'+@col_name+' default '+@def_var+' for '+@col_name
	print(@command)
	exec(@command)
go

