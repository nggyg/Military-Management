
create   procedure add_column(@tab_name varchar(50),@col_name varchar(50),@col_type varchar(50),@check int)
as
	declare @command nvarchar(max)
	set @command='alter table '+@tab_name+' add '+@col_name+' '+@col_type
	print(@command)
	exec(@command)
	if(@check=1)
		declare @ver int
		exec @ver=get_curr_ver
		insert into Proc_history(id,Proc_name,col1,col2)
		values (@ver,'add_column',@tab_name,@col_name)
		update versions set id=id+1
go

