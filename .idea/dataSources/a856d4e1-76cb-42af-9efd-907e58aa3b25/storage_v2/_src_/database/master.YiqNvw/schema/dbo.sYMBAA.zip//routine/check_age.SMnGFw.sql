create   function check_age(@age int)
returns int as
begin
	if (@age>14)and(@age<75)
	begin
		return 1
	end
	return 0
end
go

