create   procedure select_volunteers(@requiered_nr int,@min_age int =0)
as
begin
	declare @counter int =0, @req_reaced bit =0, @nrmat int, @vname varchar(50),@age int, @vol bit
	declare stud_selector cursor scroll for
		select a.NrMat,a.VName,a.age, a.volunteering
		from Applicants a
		where age>=@min_age
		order by NrMat
	open stud_selector
		fetch first from stud_selector
		into @nrmat,@vname,@age, @vol
		while @@FETCH_STATUS=0 and @req_reaced=0
		begin
			if (@vol = 0)
				begin
					update Applicants
					set volunteering=1
					where NrMat=@nrmat and VName=@vname

					insert into dbo.volunteers(NrMat,VName,age)
					values(@nrmat,@vname,@age)

					set @counter=@counter+1
				end
			fetch next from stud_selector
			into @nrmat,@vname,@age, @vol
			if(@counter>=@requiered_nr)
			begin
				set @req_reaced=1
			end
		end
	close stud_selector
	deallocate stud_selector
	if(@req_reaced=0)
	begin
		print('not enough aplicants')
	end
end
go

