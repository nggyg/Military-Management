
create   procedure RB_add_column(@tab_name varchar(50),@col_name varchar(50))
as
	declare @command nvarchar(max)
	set @command='alter table '+@tab_name+' drop column '+@col_name
	print(@command)
	exec(@command)
go

