
create   function get_col_type(@tab varchar(50),@col varchar(50))
returns varchar(50) as
begin
	declare @dt varchar(50)
	select @dt=DATA_TYPE
	from INFORMATION_SCHEMA.COLUMNS
	where TABLE_NAME=@tab and COLUMN_NAME=@col
	return @dt
end
go

