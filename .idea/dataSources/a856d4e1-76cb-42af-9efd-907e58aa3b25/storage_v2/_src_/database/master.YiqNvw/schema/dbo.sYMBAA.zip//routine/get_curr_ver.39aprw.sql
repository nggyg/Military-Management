create   procedure get_curr_ver
as
	select id
	from versions
go

