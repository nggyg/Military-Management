
create   procedure add_constr_for(@tab_name varchar(50),@col_name varchar(50),@reftab_name varchar(50),@refcol_name varchar(50), @check int)
as
	if(@check=1)
		declare @ver int
		exec @ver=get_curr_ver
		insert into Proc_history(id,proc_name,col1,col2)
		values(@ver,'add_constr_for',@tab_name,'PK_'+@tab_name+'_'+@reftab_name)
		update versions set id=id+1
	declare @com nvarchar(max)
	set @com='alter table '+@tab_name+
		' add constraint PK_'+@tab_name+'_'+@reftab_name+
		' foreign key ('+@col_name+
		') references '+@reftab_name+
		'('+@refcol_name+');'
	print(@com)
	exec(@com)
go

