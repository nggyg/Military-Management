
create   procedure fake_update
as
begin
	update Applicants
	set VName='Fake '+VName
	where NrMat like '_'
end
go

